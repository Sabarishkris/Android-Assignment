package com.example.activitylifecycle

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Set the content view first

        val button: Button = findViewById(R.id.buttona1)
        button.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish() // Finish the current activity if you want to remove it from the back stack
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("start 1", "on start")
    }

    override fun onResume() {
        super.onResume()
        Log.d("resume 1", "on resume")
    }

    override fun onStop() {
        super.onStop()
        Log.d("stop 1", "on stop")
    }

    override fun onPause() {
        Log.d("pause 1", "on pause")
        super.onPause()
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("restart 1", "on Restart")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("on destroy 1", "on Destroy")
    }
}
