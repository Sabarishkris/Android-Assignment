package com.example.activitylifecycle

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.Navigation

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

    }
    override fun onStart() {
        Log.d("start 2 ","on start")
        super.onStart()

    }

    override fun onResume() {
        Log.d("resume 2 ","on resume")
        super.onResume()
    }
    override fun onPause() {
        Log.d("pause 2", "on pause")
        super.onPause()
    }
    override fun onStop() {
        Log.d("stop 2 ","on stop")
        super.onStop()
    }

    override fun onRestart() {
        Log.d("restart 2 ","on Restart")
        super.onRestart()
    }

    override fun onDestroy() {
        Log.d("on destroy 2 ","on Destroy")
        super.onDestroy()
    }
}