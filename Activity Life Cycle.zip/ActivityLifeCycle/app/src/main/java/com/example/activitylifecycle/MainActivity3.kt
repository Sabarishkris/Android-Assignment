package com.example.activitylifecycle

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main3)

    }
    override fun onStart() {
        Log.d("start 3 ","on start")
        super.onStart()

    }

    override fun onResume() {
        Log.d("resume 3 ","on resume")
        super.onResume()
    }
    override fun onPause() {
        Log.d("pause 3", "on pause")
        super.onPause()
    }
    override fun onStop() {
        Log.d("stop 3 ","on stop")
        super.onStop()
    }

    override fun onRestart() {
        Log.d("restart 3 ","on Restart")
        super.onRestart()
    }

    override fun onDestroy() {
        Log.d("on destroy 3 ","on Destroy")
        super.onDestroy()
    }
}