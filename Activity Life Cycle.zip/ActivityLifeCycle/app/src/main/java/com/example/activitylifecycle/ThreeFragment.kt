package com.example.activitylifecycle

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.Navigation


class ThreeFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view=inflater.inflate(R.layout.fragment_three, container, false)
        val button:Button?=view?.findViewById(R.id.buttonf3)
        button?.setOnClickListener {
            val i= Intent(requireContext(),MainActivity3::class.java)
            startActivity(i)
        }

        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("create f3 ","on create")
    }

    override fun onStart() {
        Log.d("start f3 ","on start")
        super.onStart()

    }

    override fun onResume() {
        Log.d("resume f3 ","on resume")
        super.onResume()
    }
    override fun onPause() {
        Log.d("pause f3", "on pause")
        super.onPause()
    }
    override fun onStop() {
        Log.d("stop f3 ","on stop")
        super.onStop()
    }

    override fun onDestroy() {
        Log.d("on destroy f3 ","on Destroy")
        super.onDestroy()
    }

}