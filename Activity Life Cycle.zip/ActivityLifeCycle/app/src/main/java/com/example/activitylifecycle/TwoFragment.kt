package com.example.activitylifecycle

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.Navigation

class TwoFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view=inflater.inflate(R.layout.fragment_two, container, false)
        val button : Button? =view?.findViewById(R.id.buttonf2)
        button?.setOnClickListener {
            Navigation.findNavController(view).navigate(R.id.action_twoFragment_to_threeFragment)
        }
        // Inflate the layout for this fragment
        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("create f2 ","on create")
    }

    override fun onStart() {
        Log.d("start f2 ","on start")
        super.onStart()

    }
    override fun onPause() {
        Log.d("pause f2", "on pause")
        super.onPause()
    }
    override fun onResume() {
        Log.d("resume f2 ","on resume")
        super.onResume()
    }
    override fun onStop() {
        Log.d("stop f2 ","on stop")
        super.onStop()
    }

    override fun onDestroy() {
        Log.d("on destroy f2 ","on Destroy")
        super.onDestroy()
    }
}