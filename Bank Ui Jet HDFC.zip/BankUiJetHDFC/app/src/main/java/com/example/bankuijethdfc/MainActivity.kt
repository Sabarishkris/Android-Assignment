package com.example.compose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.focusModifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.motionEventSpy
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.bankuijethdfc.R

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    backGround()
                }
            }
        }
    }
}

@Composable
fun backGround() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.onPrimaryContainer)
    ) {
        TopImage()
        CenterLogin()
        BottomImage()
    }
}

@Composable
fun BottomImage() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomStart
    ) {

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomStart) {

            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(bottom = 40.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // First Box with Image and Text
                    Column(
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                    Column( // sec Box with Image and Text
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                    Column( // third Box with Image and Text
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    //.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    // First Box with Image and Text
                    Column(
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                    Column( // sec Box with Image and Text
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                    Column( // third Box with Image and Text
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(60.dp)
                                .height(60.dp)
                                .padding(10.dp)
                                .background(Color.White, shape = RoundedCornerShape(500.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                verticalArrangement = Arrangement.Bottom,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.home),
                                    contentDescription = null,
                                    modifier = Modifier.size(60.dp)
                                )

                            }

                        }
                        Text(
                            text = "Home Loan",
                            fontSize = 10.sp,
                            color = Color.White
                        )
                    }
                }

            }

        }
    }
}


@Composable
fun TopImage() {
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Image(
            painter = painterResource(id = R.drawable.madedigitalhdfc),
            contentDescription = null,
            modifier = Modifier
                .width(200.dp)
                .height(50.dp)
        )
    }
}

@Composable
fun CenterLogin() {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .width(250.dp)
                .height(470.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .offset(y = 55.dp)
                        .zIndex(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.avatar),
                        contentDescription = null,
                        modifier = Modifier.size(150.dp)
                    )
                }
            Box(
                modifier = Modifier
                    .width(250.dp)
                    .height(230.dp)
                    .background(Color.White, shape = RoundedCornerShape(12.dp))
            ) {

                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(16.dp),
                ) {
                    Text(
                        text = "Welcome,BALA KRISHNAN",
                        fontSize = 15.sp,
                        color = Color.Black,
                        modifier = Modifier.padding(4.dp)
                    )
                    Text(
                        text = "Log in with ",
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(5.dp)
                    )

                    Box(
                        modifier = Modifier
                            .background(Color.White, shape = RoundedCornerShape(12.dp))
                            .border(2.dp, Color.Blue, shape = RoundedCornerShape(12.dp))
                            .width(200.dp)
                            .height(40.dp)
                            .align(Alignment.CenterHorizontally)

                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(10.dp)
                                .align(Alignment.Center),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "FingerPrint",
                                modifier = Modifier
                                    .background(color = MaterialTheme.colorScheme.inversePrimary)
                                    .padding(end = 5.dp)
                                    .padding(start = 5.dp),
                                fontSize = 10.sp, color = Color.Blue
                            )
                            Text(
                                text = "4-Digit PIN",
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(start = 5.dp, end = 5.dp),
                                fontSize = 10.sp, color = Color.Black
                            )
                            Text(
                                text = "Password",
                                modifier = Modifier.align(Alignment.CenterVertically),
                                fontSize = 10.sp, color = Color.Black
                            )
                        }
                    }
                    Text(
                        text = "",
                        fontSize = 1.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(5.dp)
                    )
                    Box(
                        modifier = Modifier
                            .background(color = Color.Blue)
                            .width(200.dp)
                            .height(40.dp)
                            .align(Alignment.CenterHorizontally)

                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()

                                .align(Alignment.Center),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.fingerprint),
                                contentDescription = null,
                                modifier = Modifier

                            )
                            Text(
                                text = "Log in with Fingerprint",
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(start = 5.dp, end = 5.dp),
                                fontSize = 10.sp, color = Color.White
                            )
                        }
                    }
                    Text(
                        text = "__________________________________",
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(5.dp)
                    )
                    Text(
                        text = "Not BALA KRISHNAN?Add Another User",
                        fontSize = 5.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(5.dp)
                    )
                    Text(
                        text = "Secure Banking | Privacy Policy",
                        fontSize = 5.sp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                    )

                }


            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    AppTheme {
        backGround()
    }
}
