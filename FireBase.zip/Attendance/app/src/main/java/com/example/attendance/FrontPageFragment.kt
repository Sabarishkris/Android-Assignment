package com.example.attendance

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import com.example.attendance.databinding.FragmentFrontPageBinding


class FrontPageFragment : Fragment() {
private lateinit var binding: FragmentFrontPageBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_front_page, container, false)
        binding.viewAttendance.setOnClickListener {
            view?.findNavController()?.navigate(R.id.action_frontPageFragment_to_viewAttendance)
        }
        binding.markAttendance.setOnClickListener {
            view?.findNavController()?.navigate(R.id.action_frontPageFragment_to_markAttendance)
        }

        return binding.root
    }

}