package com.example.attendance

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.attendance.databinding.FragmentMarkAttendanceBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MarkAttendance : Fragment() {
    private lateinit var databaseReference: DatabaseReference
private lateinit var binding: FragmentMarkAttendanceBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        databaseReference= FirebaseDatabase.getInstance().getReference();
        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_mark_attendance, container, false)

        binding.present.setOnClickListener {
            val name=binding.name.text.toString()
            databaseReference.child(name).setValue("Present")
            binding.name.text.clear()
            Toast.makeText(requireContext(),"Marked as present", Toast.LENGTH_SHORT).show()
        }
        binding.absent.setOnClickListener {
            val name=binding.name.text.toString()
            databaseReference.child(name).setValue("Absent")
            binding.name.text.clear()
            Toast.makeText(requireContext(),"Marked as absent", Toast.LENGTH_SHORT).show()
        }
        return binding.root
    }

}