import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.attendance.R

class Adapter(private val items: List<String>,private var itemClicked: ItemClicked) : RecyclerView.Adapter<Adapter.ViewHolder>() {

    class ViewHolder(itemView: View,itemClicked: ItemClicked) : RecyclerView.ViewHolder(itemView) {
        init {
            val delete:Button=itemView.findViewById(R.id.delete)
            delete.setOnClickListener { itemClicked.deleteItem(adapterPosition) }
        }
        val textView: TextView = itemView.findViewById(R.id.text_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_view, parent, false)
        return ViewHolder(view,itemClicked)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text = items[position]
    }

    override fun getItemCount(): Int {
        Log.d("msg", items.size.toString())
        return items.size
    }
}
interface ItemClicked{
    fun deleteItem(position:Int)
}