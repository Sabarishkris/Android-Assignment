package com.example.attendance.viewattendance

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.attendance.R
import com.example.attendance.databinding.FragmentViewAttendanceBinding


class ViewAttendance : Fragment() {
    private lateinit var binding: FragmentViewAttendanceBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewModel: ViewAttendanceModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_view_attendance, container, false
        )
        recyclerView = binding.recycleView
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager=LinearLayoutManager(requireContext().applicationContext)

        viewModel = ViewModelProvider(this).get(ViewAttendanceModel::class.java)

        viewModel.init(recyclerView, this)

        return binding.root
    }


}