package com.example.attendance.viewattendance

import Adapter
import ItemClicked
import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

@SuppressLint("StaticFieldLeak")
class ViewAttendanceModel : ViewModel(),ItemClicked {
    private lateinit var data: DatabaseReference

    private lateinit var recyclerView: RecyclerView
    private lateinit var context: ViewAttendance
    private lateinit var adapter: Adapter
    private lateinit var ls: MutableList<String>

    @SuppressLint("NotifyDataSetChanged")
    fun init(recyclerView: RecyclerView, context: ViewAttendance) {
        this.recyclerView = recyclerView
        this.context = context
        ls = mutableListOf()
        addValue()
        Log.d("msg","2")
        adapter = Adapter(ls,this)
        recyclerView.adapter = adapter


    }

    @SuppressLint("NotifyDataSetChanged")
    private fun addValue() {
        data = FirebaseDatabase.getInstance().getReference()

        data.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val name = snapshot.key + ": " + snapshot.value.toString()
                ls.add(name)
                adapter.notifyItemInserted(ls.size - 1)
                Log.d("msg",name)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val name = snapshot.key + ": " + snapshot.value.toString()
                val index = ls.indexOfFirst { it.startsWith(snapshot.key!!) }
                if (index != -1) {
                    ls[index] = name
                    adapter.notifyItemChanged(index)
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val index = ls.indexOfFirst { it.startsWith(snapshot.key!!) }
                if (index != -1) {
                    ls.removeAt(index)
                    adapter.notifyItemRemoved(index)
                }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle child moved if needed
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle possible errors
                error.toException().printStackTrace()
            }
        })

    }

    override fun deleteItem(position: Int) {
        val name =ls[position]
        val key=name.substringBefore(":")
        data.child(key).removeValue().addOnSuccessListener {
            Log.d("msg","Deleted")
        }.addOnFailureListener{
            Log.d("msg","Failed")
        }
    }
}
