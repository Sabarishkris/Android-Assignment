package com.example.weatherapp.data

data class CurrentNews(
    val articles: List<Article>,
    val status: String,
    val totalResults: Int
)