package com.example.weatherapp.data

data class Source(
    val id: String,
    val name: String
)