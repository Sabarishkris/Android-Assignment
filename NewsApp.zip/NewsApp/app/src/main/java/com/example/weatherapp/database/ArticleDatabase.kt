package com.example.weatherapp.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
@Database(entities = [Article::class], version = 2, exportSchema = false)
abstract class ArticleDatabase : RoomDatabase() {
    companion object {
        private var instance: ArticleDatabase? = null
        fun getInstance(context: Context): ArticleDatabase? {
            if (instance == null) {
                synchronized(ArticleDatabase::class.java) {
                    instance = Room.databaseBuilder(
                        context.applicationContext, ArticleDatabase::class.java,
                        "ArticleDatabase"
                    ).fallbackToDestructiveMigration().build()
                }
            }
            return instance
        }

    }
    abstract fun articledatabasedao():ArticleDatabaseDAO
}