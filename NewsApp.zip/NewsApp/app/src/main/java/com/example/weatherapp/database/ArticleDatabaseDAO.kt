package com.example.weatherapp.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface ArticleDatabaseDAO {
    @Insert
    fun insert(article: Article)
    @Update
    fun update(article: Article)
    @Delete
    fun delete(article: Article)
    @Query("delete from Article")
    fun deleteAll()
    @Query("select * from Article")
    fun getArticle():List<Article>

}