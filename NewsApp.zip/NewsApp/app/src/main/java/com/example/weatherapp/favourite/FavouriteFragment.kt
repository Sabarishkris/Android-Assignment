package com.example.weatherapp.favourite

import Favouritemodel
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.weatherapp.R
import com.example.weatherapp.database.Article
import com.example.weatherapp.databinding.FragmentFavouriteBinding
import com.squareup.picasso.Picasso

class FavouriteFragment : Fragment() {
    private lateinit var binding: FragmentFavouriteBinding
    private lateinit var viewModel: Favouritemodel

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_favourite, container, false)
        val arguments = FavouriteFragmentArgs.fromBundle(requireArguments())
        val imrl = arguments.image
        Picasso.get().load(imrl).into(binding.feedImage)
        binding.headerTitle.text = arguments.title
        binding.author.text = arguments.author
        binding.desc.text = arguments.desc
        if(arguments.url.isNotBlank()){
            binding.url.text = arguments.url
        }else{
            binding.url.text=""
        }
        binding.published.text = arguments.published
        binding.content.text = arguments.content
        viewModel = ViewModelProvider(this).get(Favouritemodel::class.java)
        binding.favouriteButton.setOnClickListener {
            viewModel.storeData(
                requireContext().applicationContext,
                binding.headerTitle.text.toString(),
                binding.author.text.toString(),
                binding.desc.text.toString(),
                binding.url.text.toString(),
                binding.published.text.toString(),
                binding.content.text.toString()," "
            )
            binding.favouriteButton.setImageResource(R.drawable.heartdark)
        }

        return binding.root
    }


}