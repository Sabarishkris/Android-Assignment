import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.weatherapp.database.Article
import com.example.weatherapp.database.ArticleDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Repository(private val applicationContext: Context) {
    private val database: ArticleDatabase = ArticleDatabase.getInstance(applicationContext)!!
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val _list = MutableLiveData<List<Article>>()
    val list: LiveData<List<Article>> get() = _list

    fun storeData(
        title: String,
        author: String,
        description: String,
        url: String,
        published: String,
        content: String,
    ) {
        coroutineScope.launch {
            try {
                val article = Article(0, author, content, description, published, title, url)
                database.articledatabasedao().insert(article)
                Log.d("Repository", "Data saved")
            } catch (e: Exception) {
                Log.e("Repository", "Error saving data", e)
            }
        }
    }

    fun getList() {
        coroutineScope.launch {
            try {
                val articles = database.articledatabasedao().getArticle()
                withContext(Dispatchers.Main) {
                    _list.value = articles
                }
                Log.d("Repository", "List retrieved")
            } catch (e: Exception) {
                Log.e("Repository", "Error retrieving list", e)
            }
        }
    }

    fun deleteAll() {
        coroutineScope.launch {
            try {
                 database.articledatabasedao().deleteAll()
                    Log.d("Repository", "All deleted")
            } catch (e: Exception) {
                Log.e("Repository", "Error delete all", e)
            }
        }
    }

    fun deleteItem(news: Article?) {

        coroutineScope.launch {
            try {
                if (news != null) {
                    database.articledatabasedao().delete(news)
                }
                Log.d("Repository", " deleted")
            } catch (e: Exception) {
                Log.e("Repository", "Error delete ", e)
            }
        }
    }
}
