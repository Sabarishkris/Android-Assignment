package com.example.weatherapp.language

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.languagedata.New
import com.squareup.picasso.Picasso

class LanguageAdapter(var list: List<New>, private var setClick: SetClick) :
    RecyclerView.Adapter<LanguageAdapter.ViewHolder>() {
    class ViewHolder(view: View, setClick: SetClick) : RecyclerView.ViewHolder(view) {
        init {
            itemView.setOnClickListener { setClick.itemClicked(adapterPosition) }
        }



        val image: ImageView = view.findViewById(R.id.news_image)
        val title: TextView = view.findViewById(R.id.news_heading)
        val subtitle: TextView = view.findViewById(R.id.sub_title)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.footer_layout, parent, false)
        return ViewHolder(view, setClick)
    }

    override fun getItemCount(): Int {
        Log.e("LanguageModel", "Adapter Done ${list.size}")
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Log.e("LanguageModel", "Adapter Done")
        val news: New = list[position]
        val imrl = news.image
        Picasso.get().load(imrl).into(holder.image)
        holder.title.text = news.title
        holder.subtitle.text = news.description
    }
}

interface SetClick {
    fun itemClicked(position: Int)
}