package com.example.weatherapp.language

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.ui.AppBarConfiguration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.databinding.FragmentLanguageBinding
import com.google.android.material.navigation.NavigationView

class LanguageFragment : Fragment() {

    private lateinit var binding: FragmentLanguageBinding
    private lateinit var viewModel: LanguageModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_language, container, false)
        viewModel = ViewModelProvider(this).get(LanguageModel::class.java)
        val args = LanguageFragmentArgs.fromBundle(requireArguments())
        var category: String = args.category
        recyclerView = binding.newsFeed
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        viewModel.initialize(requireContext(), recyclerView, category)
//        viewModel.setFeed(recyclerView)

        (activity as AppCompatActivity).setSupportActionBar(binding.appToolbar)
        drawerLayout = binding.drawLayout
        navView = binding.navView
        toggle = ActionBarDrawerToggle(
            activity,
            drawerLayout,
            binding.appToolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        appBarConfiguration = AppBarConfiguration(setOf(R.id.languageFragment), drawerLayout)
        navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.tamil -> {
                    viewModel.initialize(requireContext(), recyclerView, "tamil")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.arabic -> {
                    viewModel.initialize(requireContext(), recyclerView,"arabic")
                    drawerLayout.closeDrawers()
                    true
                }


                R.id.danish -> {
                    viewModel.initialize(requireContext(), recyclerView,"danish")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.french -> {
                    viewModel.initialize(requireContext(), recyclerView,"french")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.korean -> {
                    viewModel.initialize(requireContext(), recyclerView,"korean")
                    drawerLayout.closeDrawers()
                    true
                }
                else -> false
            }
        }
        return binding.root
    }


}