package com.example.weatherapp.language

import android.content.Context
import com.example.weatherapp.api.LanguageApi
import com.example.weatherapp.languagedata.LanguageNews
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class LanguageRepository(applicationContext: Context) {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://newsapi.in/newsapi/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    private val apiService = retrofit.create(LanguageApi::class.java)

    suspend fun getlist(apiKey: String, category: String): Response<LanguageNews> {
        return apiService.getTopHeadlines(apiKey, category)
    }
}