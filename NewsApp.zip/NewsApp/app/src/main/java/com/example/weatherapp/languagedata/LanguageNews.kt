package com.example.weatherapp.languagedata

data class LanguageNews(
    val News: List<New>,
    val success: Int
)