package com.example.weatherapp.news

import android.os.Bundle

import android.view.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity

import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R

import com.example.weatherapp.databinding.FragmentAppFrontPageBinding

import com.example.weatherapp.weather.WeatherModel
import com.google.android.material.navigation.NavigationView

class AppFrontPageFragment : Fragment() {
    private lateinit var binding: FragmentAppFrontPageBinding
    private lateinit var viewModel: NewsFeedModel
    private lateinit var headerRecyclerView: RecyclerView
    private lateinit var feedRecyclerView: RecyclerView
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var weatherModel: WeatherModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_app_front_page, container, false)
        viewModel = ViewModelProvider(this)[NewsFeedModel::class.java]
        weatherModel = ViewModelProvider(this)[WeatherModel::class.java]


        headerRecyclerView = binding.categoryFeed
        feedRecyclerView = binding.newsFeed
        headerRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        feedRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        viewModel.initialize(requireContext(), headerRecyclerView, feedRecyclerView)
        viewModel.setFeed(feedRecyclerView)
        viewModel.setHeader(headerRecyclerView)

        (activity as AppCompatActivity).setSupportActionBar(binding.appToolbar)
        drawerLayout = binding.drawLayout
        navView = binding.navView
        toggle = ActionBarDrawerToggle(
            activity,
            drawerLayout,
            binding.appToolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        appBarConfiguration = AppBarConfiguration(setOf(R.id.appFrontPageFragment), drawerLayout)

        navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.tamil -> {
                    viewModel.sendDirection("tamil")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.arabic -> {
                    viewModel.sendDirection("arabic")
                    drawerLayout.closeDrawers()
                    true
                }


                R.id.danish -> {
                    viewModel.sendDirection("danish")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.french -> {
                    viewModel.sendDirection("french")
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.korean -> {
                    viewModel.sendDirection("korean")
                    drawerLayout.closeDrawers()
                    true
                }

                else -> false
            }
        }
        binding.weather.setOnClickListener {
            weatherModel.fetchWeather("chennai","metric",getString(R.string.api_key))
            view?.findNavController()?.navigate(R.id.action_appFrontPageFragment_to_weatherFragment)
        }
        return binding.root
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.favouritemenu -> {
                view?.findNavController()
                    ?.navigate(R.id.action_appFrontPageFragment_to_favouriteViewFragment)
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

}
