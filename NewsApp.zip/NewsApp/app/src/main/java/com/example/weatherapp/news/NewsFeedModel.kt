package com.example.weatherapp.news

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.data.Article
import kotlinx.coroutines.launch

class NewsFeedModel : ViewModel(), NewsHeadingCategory.ClickOnCategory, SetClick {
    private lateinit var repository: Repository

    @SuppressLint("StaticFieldLeak")
    private lateinit var recyclerViewh: RecyclerView

    @SuppressLint("StaticFieldLeak")
    private lateinit var recyclerViewf: RecyclerView
    private lateinit var adapterf: NewsFeedAdapter
    private lateinit var category1: String
    private lateinit var adapterh: NewsHeadingCategory

    private val _news = MutableLiveData<List<Article>>()
    val news: LiveData<List<Article>> get() = _news

    private val _category = MutableLiveData<List<String>>()
    val category: LiveData<List<String>> get() = _category

    fun initialize(
        applicationContext: Context, recyclerViewh: RecyclerView,
        recyclerViewf: RecyclerView
    ) {
        this.recyclerViewh = recyclerViewh
        this.recyclerViewf = recyclerViewf
        repository = Repository(applicationContext)
        category1 = "entertainment"
        fetchNews(category1, "87224693c3cf46b2afd835fb14da8474")

        val categories = listOf(
            "Entertainment", "Sports", "politics",
            "Health", "Science", "Technology", "Business"
        )
        _category.postValue(categories)
    }

    private fun fetchNews(category: String, apiKey: String) {

        viewModelScope.launch {
            try {
                val response = repository.getlist(category, apiKey)
                if (response.isSuccessful) {
                    _news.postValue(response.body()?.articles ?: emptyList())
                } else {
                    Log.e("NewsFeedModel", "Error fetching news1: ${response.message()}")
                    _news.postValue(emptyList())
                }
            } catch (e: Exception) {
                Log.e("NewsFeedModel", "Exception fetching news", e)
                _news.postValue(emptyList())
            }
        }
    }

    override fun clickONListenerCategory(category: String) {
        category1 = category
        fetchNews(category1, "87224693c3cf46b2afd835fb14da8474")
        setFeed(recyclerViewf)

    }

    @SuppressLint("NotifyDataSetChanged")
    fun setFeed(recyclerView: RecyclerView) {
        _news.observeForever { articles ->
            if (articles != null) {
                adapterf = NewsFeedAdapter(articles, this)
                recyclerView.adapter = adapterf
                adapterf.notifyDataSetChanged()
            } else {
                Log.e("NewsFeedModel", "No articles to display")
            }
        }
    }

    fun setHeader(recyclerViewh: RecyclerView) {
        category.observeForever { categories ->
            if (categories != null) {
                recyclerViewh.adapter = NewsHeadingCategory(categories, this)
            } else {
                Log.e("NewsFeedModel", "No categories to display")
            }

        }

    }

    override fun itemClicked(position: Int) {
        var article = _news.value
        var articles: Article? = article?.get(position)
        var title = if (articles?.title == null) null else articles.title
        var desc = articles?.description
        var content = articles?.content
        var image = articles?.urlToImage
        var author = articles?.author
        var published = articles?.publishedAt
        var url = articles?.url
        var urlToImage = articles?.urlToImage
        var source = articles?.source
        val action = AppFrontPageFragmentDirections.actionAppFrontPageFragmentToFavouriteFragment(
            title.toString(),
            desc.toString(),
            content.toString(),
            image.toString(),
            author.toString(),
            published.toString(),
            url.toString(),
            urlToImage.toString()
        )
        recyclerViewf.findNavController().navigate(action)
    }

    override fun dustBin(adapterPosition: Int) {
        TODO("Not yet implemented")
    }

    fun sendDirection(category: String) {
        val action=AppFrontPageFragmentDirections.actionAppFrontPageFragmentToLanguageFragment(category)
        recyclerViewf.findNavController().navigate(action)
    }
}
