package com.example.weatherapp.news

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.example.weatherapp.api.ApiInterface
import com.example.weatherapp.data.CurrentNews
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Repository(applicationContext: Context) {

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://newsapi.org/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    private val apiService = retrofit.create(ApiInterface::class.java)

    suspend fun getlist(category: String, apiKey: String): Response<CurrentNews> {
        return apiService.getTopHeadlines(category, apiKey)
    }
}
