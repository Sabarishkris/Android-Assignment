package com.example.weatherapp.offline

import Favouritemodel
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.example.weatherapp.R
import com.example.weatherapp.database.Article
import com.example.weatherapp.databinding.FragmentOfflineViewfragmentBinding
import com.example.weatherapp.favourite.FavouriteFragmentArgs
import com.squareup.picasso.Picasso


class OfflineViewfragment : Fragment() {
private lateinit var binding: FragmentOfflineViewfragmentBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var arguments = OfflineViewfragmentArgs.fromBundle(requireArguments())
        binding=DataBindingUtil.inflate(inflater,R.layout.fragment_offline_viewfragment, container, false)
        binding.headerTitle.text = if(arguments.title.equals("null")){""}else{arguments.title}
        binding.author.text =if(arguments.author.equals("null")){""}else{arguments.author}
        binding.desc.text = if(arguments.desc.equals("null")){""}else{arguments.desc}
        if(arguments.url.isNotBlank()){
            binding.url.text = arguments.url
        }else{
            binding.url.text=""
        }
        binding.published.text = if(arguments.published.equals("null")){""}else{arguments.published}
        binding.content.text = if(arguments.content.equals("null")){""}else{arguments.content}
        (activity as AppCompatActivity).setSupportActionBar(binding.appToolbar)
        return binding.root
    }

}