package com.example.weatherapp.weather

import android.annotation.SuppressLint
import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.R
import com.example.weatherapp.model.CurrentWeather
import com.example.weatherapp.weatherdata.RetrofitInstance
import com.google.android.gms.location.FusedLocationProviderClient
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale

class WeatherModel:ViewModel() {
    private val _weatherData = MutableLiveData<CurrentWeather?>()
    val weatherData: LiveData<CurrentWeather?> get() = _weatherData
    fun fetchWeather(location: String,unit:String ,apiKey: String, ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitInstance.retrofit.getCurrentWeather(location, unit, apiKey)
                Log.i("msg","Done")
                if (response.isSuccessful && response.body() != null) {
                    _weatherData.postValue(response.body())
                } else {
                    _weatherData.postValue(null)
                }
            } catch (e: Exception) {
                _weatherData.postValue(null)
            }

        }
    }



    @SuppressLint("MissingPermission")
    fun getCurrentLocation(
        fusedLocationClient: FusedLocationProviderClient,
        applicationContext: Context
    ) {
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude
                var countryName=getCountryName(applicationContext,latitude,longitude).toString()
                fetchWeather(
                    countryName,
                    "metric",
                    applicationContext.getString(R.string.api_key)
                )
            } else {
                Toast.makeText(applicationContext, "Unable to get location", Toast.LENGTH_SHORT).show()
            }
        }
    }
    @SuppressLint("SetTextI18n")
    fun retrive(): CurrentWeather? {
        Log.d("retrive","retrived")
        val weather=weatherData.value
        return weather
    }

        fun getCountryName(applicationContext: Context, latitude: Double, longitude: Double): String? {
        val geocoder = Geocoder(
            applicationContext, Locale.getDefault())
        var countryName: String? = null

        try {
            val addresses: MutableList<Address>? = geocoder.getFromLocation(latitude, longitude, 1)
            if (addresses != null) {
                if (addresses.isNotEmpty()) {
                    countryName = addresses?.get(0)?.countryName
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return countryName
    }

}