package com.example.weatherapp.weatherdata

object Util {
    val base:String="https://api.openweathermap.org/data/2.5/"
}