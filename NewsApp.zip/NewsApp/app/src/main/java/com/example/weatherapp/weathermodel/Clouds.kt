package com.example.weatherapp.weathermodel

data class Clouds(
    val all: Int
)