package com.example.weatherapp.model

data class Coord(
    val lat: Double,
    val lon: Double
)