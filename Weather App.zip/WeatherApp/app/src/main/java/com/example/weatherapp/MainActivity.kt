package com.example.weatherapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.ViewModelProvider
import com.example.weatherapp.data.WeatherModel
import com.example.weatherapp.databinding.ActivityMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.squareup.picasso.Picasso
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var weatherModel: WeatherModel
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        weatherModel = ViewModelProvider(this).get(WeatherModel::class.java)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
      requestLocationPermission()
        weatherModel.getCurrentLocation(fusedLocationClient,applicationContext)
        assignValue()
        binding.button.setOnClickListener {
            weatherModel.fetchWeather(binding.typeText.text.toString(), "metric",
                applicationContext.getString(R.string.api_key))
            assignValue()
            onStart()
        }
    }
    fun requestLocationPermission() {
        MainActivity.LOCATION_PERMISSION_REQUEST_CODE
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            MainActivity.LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    @SuppressLint("SetTextI18n")
    private fun assignValue() {
        weatherModel.weatherData.observe(this) { weather ->
            weather?.let {
                binding.apply {
                    val imrl = "https://openweathermap.org/img/wn/${it.weather[0].icon}.png"
                    Picasso.get().load(imrl).into(celsiusImage)
                    Location.text = it.name
                    update.text = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
                        .format(it.dt * 1000)
                    celsiusTemp.text = "${it.main.temp.toInt()}°C"
                    minTemp.text = "Min temp ${it.main.temp_min.toInt()} %"
                    maxTemp.text = "Max temp ${it.main.temp_max.toInt()} %"
                    sunrise.text = SimpleDateFormat("hh:mm a ", Locale.ENGLISH)
                        .format(it.sys.sunrise * 1000)
                    sunset.text = SimpleDateFormat("hh:mm a ", Locale.ENGLISH)
                        .format(it.sys.sunset * 1000)
                    windSpeed.text = "${it.wind.speed} KM/H"
                    humidity.text = "${it.main.humidity} %"
                    pressure.text = "${it.main.pressure} hpa"

                }
            } ?: run {
                Toast.makeText(
                    applicationContext,
                    "Error fetching weather data",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }


    }
    companion object{
        const val LOCATION_PERMISSION_REQUEST_CODE=1
    }

}

