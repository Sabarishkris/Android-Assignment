package com.example.weatherapp.data

object Util {
    val base:String="https://api.openweathermap.org/data/2.5/"
}