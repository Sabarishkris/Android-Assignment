package com.example.weatherapp.model

data class Clouds(
    val all: Int
)