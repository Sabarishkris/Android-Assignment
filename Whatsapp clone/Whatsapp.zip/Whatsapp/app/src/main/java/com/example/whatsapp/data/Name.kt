package com.example.whatsapp.data

data class Name(
    val first: String,
    val last: String,
    val title: String
)