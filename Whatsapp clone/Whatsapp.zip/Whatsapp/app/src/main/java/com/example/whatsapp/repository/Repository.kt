package com.example.whatsapp.repository


import com.example.whatsapp.api.ApiResponse
import com.example.whatsapp.data.Contacts
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class Repository {
    private val BASE_URL = "https://randomuser.me/"

    val api: ApiResponse by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiResponse::class.java)
    }

    suspend fun getTopHeadlines(): Response<Contacts> {
        return api.getTopHeadlines()
    }
}