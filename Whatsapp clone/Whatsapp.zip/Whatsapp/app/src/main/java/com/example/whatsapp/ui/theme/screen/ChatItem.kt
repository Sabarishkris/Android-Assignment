package com.example.whatsapp.ui.theme.screen

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ModifierLocalBeyondBoundsLayout
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.whatsapp.R
import com.example.whatsapp.data.Result
import com.example.whatsapp.viewmodel.ViewModel


@Composable
fun ChatItem(item:Result) {
Box(modifier = Modifier
    .fillMaxWidth()
    .padding(bottom = 5.dp)){
    Row (modifier = Modifier.fillMaxWidth()){
        Log.d("ContactItemContent", "imageUrl: ${item.picture.medium}")
        Image(
            painter = rememberAsyncImagePainter(item.picture.medium),
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .size(40.dp)
                .clip(CircleShape),
            contentDescription = null,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.CenterVertically)) {
            Text(text = "${item.name.first} ${item.name.last}",
                style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = item.email, style = MaterialTheme.typography.bodySmall)
        }

    }
}
}
@Composable
fun ChatItemHorizontal(item:Result) {
    Box(modifier = Modifier
        .fillMaxWidth()){
        Column (modifier = Modifier.fillMaxWidth()){
            Log.d("ContactItemContent", "imageUrl: ${item.picture.medium}")
            Image(
                painter = rememberAsyncImagePainter(item.picture.medium),
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .size(60.dp)
                    .clip(CircleShape),
                contentDescription = null,
            )
            Spacer(modifier = Modifier.height(2.dp))
            val name ="${item.name.first} ${item.name.last}"
            val limitedText = if (name.length > 7) {
                name.substring(0,7)+ "..."
            } else {
                name
            }
            Column(modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.CenterHorizontally)) {
                Text(text = limitedText,
                    style = MaterialTheme.typography.bodySmall)
            }

        }
    }
}
//@Preview(showBackground = true)
@Composable
fun ChatItemCard(item: Result) {
//    val viewModel=ViewModel()
//    val item= viewModel.contacts.value?.results?.get(0)
   OutlinedCard(onClick = { /*TODO*/ }, modifier = Modifier.width(130.dp).wrapContentHeight().padding(5.dp),
       colors = CardDefaults.outlinedCardColors(contentColor = MaterialTheme.colorScheme.onBackground,
       containerColor = MaterialTheme.colorScheme.background)) {
       Column (modifier = Modifier.fillMaxWidth()){
           Log.d("ContactItemContent", "imageUrl: ${item?.picture?.medium}")
           Image(
               painter = rememberAsyncImagePainter(item?.picture?.medium),
               modifier = Modifier.align(Alignment.CenterHorizontally)
                   .padding(horizontal = 16.dp, vertical = 8.dp)
                   .size(60.dp)
                   .clip(CircleShape),
               contentDescription = null,
           )
           Spacer(modifier = Modifier.height(2.dp))
           val name ="${item?.name?.first} ${item?.name?.last}"
           val limitedText = if (name.length > 7) {
               name.substring(0,7)+ "..."
           } else {
               name
           }
           Column(modifier = Modifier
               .fillMaxWidth()
               .align(Alignment.CenterHorizontally)) {
               Text(text = limitedText, modifier = Modifier.align(Alignment.CenterHorizontally),
                   style = MaterialTheme.typography.bodySmall)
               Button(onClick = { /*TODO*/ }, modifier = Modifier.fillMaxWidth()
                   .padding(8.dp).height(30.dp)) {
                   Text(text = "Follow",
                       fontSize = MaterialTheme.typography.bodySmall.fontSize,
                       style = MaterialTheme.typography.bodySmall)
               }
           }

       }
   }
   }



