package com.example.whatsapp.ui.theme.screen

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Update
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.whatsapp.viewmodel.ViewModel
import com.example.whatsapp.R
import com.example.whatsapp.util.ScreenUiEvents
import com.example.whatsapp.util.UiEvents
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun WhatsappScreen(viewModel: ViewModel, navController: NavHostController) {
    val scrollState = rememberLazyListState()
    var searchText by rememberSaveable {
        mutableStateOf("")
    }
    var active by rememberSaveable {
        mutableStateOf(false)
    }
    var searchBarVisible =viewModel.isSwipe.collectAsState().value
    val swipe=rememberSwipeRefreshState(isRefreshing = searchBarVisible)
    val contacts = viewModel.contacts.value?.results ?: emptyList()
    var showMenu by remember { mutableStateOf(false) }


    val scaffold = remember {
        SnackbarHostState()
    }

    val uiEvents = viewModel.uiEvents.collectAsState(initial = null)

    uiEvents.value?.let { event ->
        LaunchedEffect(key1 = event) {
            Log.d("msgl", "enter")
            when (event) {
                is UiEvents.Navigate -> navController.navigate(event.route)
                is UiEvents.ShowSnackbar -> {
                    scaffold.showSnackbar(
                        message = event.message,
                    )
                }

                else -> Unit
            }
        }
    }


    Scaffold(modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Whatsapp",
                        fontSize = MaterialTheme.typography.titleLarge.fontSize,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ), actions = {
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = Icons.Outlined.QrCodeScanner,
                            contentDescription = ""
                        )

                    }
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = Icons.Outlined.CameraAlt,
                            contentDescription = ""
                        )

                    }

                    IconButton(onClick = { showMenu = !showMenu }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = ""
                        )
                        DropdownMenu(expanded = showMenu, onDismissRequest = {
                            showMenu = false
                        }) {
                            DropdownMenuItem(
                                text = { Text(text = "New group") },
                                onClick = {
                            })
                            DropdownMenuItem(
                                text = { Text(text = "New broadcast") },
                                onClick = { })
                            DropdownMenuItem(
                                text = { Text(text = "Linked devices") },
                                onClick = { })
                            DropdownMenuItem(
                                text = { Text(text = "Starred messages") },
                                onClick = { })
                            DropdownMenuItem(
                                text = { Text(text = "Payments") },
                                onClick = { })
                            DropdownMenuItem(
                                text = { Text(text = "Settings") },
                                onClick = { })
                        }

                    }
                })
        },
        bottomBar = {
            BottomAppBar(
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.onBackground
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    BottomBarItem(icon = Icons.AutoMirrored.Filled.Message, label = "Chats",
                        navigate={viewModel.ScreenEvents(ScreenUiEvents.ChatClicked)})
                    BottomBarItem(
                        icon = Icons.Outlined.Update,
                        label = "Updates",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.UpdatesClicked)})
                    BottomBarItem(
                        icon = Icons.Outlined.Groups,
                        label = "Communities",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.CommunitiesClicked)})
                    BottomBarItem(
                        icon = Icons.Default.Call,
                        label = "Calls",
                        navigate = {viewModel.ScreenEvents(ScreenUiEvents.CallsClicked)})
                }
            }
        }
    ) { innerPadding ->

        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                SwipeRefresh(state = swipe, onRefresh = { viewModel.swipe() }) {
                        LazyColumn(
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            item {
                                if (searchBarVisible) {
                                    Box(modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(
                                            start = 10.dp, end = 10.dp
                                        )) {
                                        SearchBar(
                                            query = searchText,
                                            onQueryChange = { searchText = it },
                                            onSearch = { active = false },
                                            active = active,
                                            onActiveChange = { active = it },
                                            placeholder = { Text(text = "Search...") },
                                            leadingIcon = {
                                                Icon(
                                                    Icons.Default.Search,
                                                    contentDescription = "Search"
                                                )
                                            }
                                        ) {}
                                    }
                                }
                            }
                            items(contacts) { contact ->
                                Log.d("WhatsappScreen", "Contact ID: ${contact.id}")
                                ChatItem(item = contact)
                            }
                        }
                    }
                }

            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                FloatingActionButton(
                    onClick = {},
                    modifier = Modifier
                        .width(50.dp)
                        .height(60.dp)
                        .padding(bottom = 16.dp),
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.meta),
                        contentDescription = "metaballs"
                    )
                }

                FloatingActionButton(
                    onClick = {},
                    modifier = Modifier
                        .width(60.dp)
                        .height(60.dp)
                        .align(Alignment.CenterHorizontally),
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.chatplus),
                        contentDescription = "Add",
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(100.dp)
                            .height(90.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BottomBarItem(icon: ImageVector, label: String, navigate: () -> Unit) {
    Column(
        modifier = Modifier.padding(8.dp).clickable {navigate.invoke()},
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            modifier = Modifier
                .width(30.dp)
                .height(30.dp)
        )
        Text(text = label, style = MaterialTheme.typography.bodySmall)
    }
}
