package com.example.whatsapp.util

sealed class ScreenUiEvents {
    object ChatClicked : ScreenUiEvents()
    object UpdatesClicked : ScreenUiEvents()
    object CommunitiesClicked : ScreenUiEvents()
    object  CallsClicked : ScreenUiEvents()

}