package com.example.whatsapp.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.whatsapp.data.Contacts
import com.example.whatsapp.data.Result
import com.example.whatsapp.repository.Repository
import com.example.whatsapp.util.Routes
import com.example.whatsapp.util.ScreenUiEvents
import com.example.whatsapp.util.UiEvents
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

class ViewModel : ViewModel() {
    sealed class ContactUiState {
        object Success : ContactUiState()
        object Error : ContactUiState()
        object Loading : ContactUiState()
    }
private val _isSwipe= MutableStateFlow(false)
    val isSwipe=_isSwipe.asStateFlow()
fun swipe(){
    viewModelScope.launch {
        _isSwipe.value = true
    }
}
    var contactUiState: ContactUiState by mutableStateOf(ContactUiState.Loading)
        private set

    private val _contacts = MutableLiveData<Contacts>()
    val contacts: LiveData<Contacts> get() = _contacts
    private val _uiEvents = Channel<UiEvents>()

    val uiEvents = _uiEvents.receiveAsFlow()
    init {
        getContacts()
    }

    private fun getContacts() {
        viewModelScope.launch {
            try {
                contactUiState = ContactUiState.Loading
                val response = Repository().getTopHeadlines()
                if (response.isSuccessful) {
                    _contacts.value = response.body()
                    contactUiState = ContactUiState.Success
                    Log.d("ViewModel", "Successfully fetched contacts")
                } else {
                    contactUiState = ContactUiState.Error
                    Log.e("ViewModel", "Error fetching contacts: ${response.message()}")
                }
            } catch (e: Exception) {
                contactUiState = ContactUiState.Error
                Log.e("ViewModel", "Exception fetching contacts", e)
            }
        }
    }



    fun ScreenEvents(events: ScreenUiEvents){
        Log.d("msg","event1")
        when(events){
            ScreenUiEvents.CallsClicked -> onSendUiEvent(UiEvents.Navigate(Routes.CALLS))
            ScreenUiEvents.ChatClicked -> onSendUiEvent(UiEvents.Navigate(Routes.CHATS))
            ScreenUiEvents.CommunitiesClicked -> onSendUiEvent(UiEvents.Navigate(Routes.COMMUNITIES))
            ScreenUiEvents.UpdatesClicked -> onSendUiEvent(UiEvents.Navigate(Routes.UPDATES))
        }

    }



    private fun onSendUiEvent(events: UiEvents) {
        viewModelScope.launch {
            Log.d("msg","$events")
            _uiEvents.send(events)
        }
    }
}
